import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

@Component({
  selector: 'app-databinding',
  templateUrl: './databinding.component.html',
  styleUrls: ['./databinding.component.css']
})
export class DatabindingComponent implements OnInit {
    year;
    age;
    currencyCode='INR'; 
  constructor(private router:Router) { }

  ngOnInit() {
  }

  ToHome(){
    this.router.navigate(['home',123]);
  }
  ageCalculator(){

        this.year = new Date().getFullYear() - this.age
      } 
  change(){
    
  }
}
