export class Product{
    constructor(public productId :number,
        public productType :string,
        public productPrice :number,
        public productQuantity :number)
        
    {}
}