import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  productArr= [
    {productId:101,productName:'Mobile',productCategory:'Electronics'},
    {productId:102,productName:'Mobile1',productCategory:'Electronics'},
    {productId:103,productName:'Mobile2',productCategory:'Electronics'},
    {productId:104,productName:'Mobile3',productCategory:'Electronics'}

  ];
}
